@echo off
rem uaRO Graphics: puts our ddraw.dll into this uaRO client folder.
rem dgVoodoo's DDraw.dll and D3DImm.dll move into uaro-graphics\dgvoodoo, kept there for uninstall.bat (2.2: unused).
rem Running it again is safe. uninstall.bat puts everything back.
setlocal
cd /d "%~dp0"
if not exist "uaRO.exe" (
    echo uaRO.exe is not in this folder.
    echo Unpack the whole archive into the uaRO client folder, next to uaRO.exe, and run install.bat again.
    goto :fail
)
if not exist "uaro-graphics\ddraw.dll" (
    echo uaro-graphics\ddraw.dll is missing: unpack the whole archive, keeping its folders.
    goto :fail
)
tasklist /fi "imagename eq uaro-graphics.exe" 2>nul | find /i "uaro-graphics.exe" >nul && (
    echo uaRO Graphics Settings is open: close it and run install.bat again.
    goto :fail
)
rem A client under Program Files can only be changed with administrator rights.
(echo test) > "uaro-graphics-write-test.tmp" 2>nul || goto :noaccess
del "uaro-graphics-write-test.tmp"
rem An update.bat of 0.11.0 or older copies only the files of uaro-graphics, not its folders (the AI model in ai,
rem RTX Remix's settings in remix), and then runs this new install.bat: the update it unpacked is still here.
if /i "%~1"=="/quiet" if exist "uaro-graphics-update\files\uaro-graphics\ddraw.dll" (
    xcopy /e /i /y /q "uaro-graphics-update\files\uaro-graphics" "uaro-graphics" >nul || goto :noaccess
)
rem 2.8: dgVoodoo's files in uaro-graphics\dgvoodoo (2.x kept them in dgvoodoo in the root: the driver moves those).
if not exist "uaro-graphics\dgvoodoo" mkdir "uaro-graphics\dgvoodoo" || goto :noaccess
rem The ddraw.dll in this folder is dgVoodoo's unless it is already ours.
if exist "ddraw.dll" (
    findstr /m /c:"uaRO Graphics" "ddraw.dll" >nul 2>&1
    if errorlevel 1 move /y "ddraw.dll" "uaro-graphics\dgvoodoo\DDraw.dll" >nul || goto :noaccess
)
if exist "D3DImm.dll" move /y "D3DImm.dll" "uaro-graphics\dgvoodoo\D3DImm.dll" >nul || goto :noaccess
if exist "dgVoodoo.conf" copy /y "dgVoodoo.conf" "uaro-graphics\dgvoodoo\dgVoodoo.conf" >nul
copy /y "uaro-graphics\ddraw.dll" "ddraw.dll" >nul || goto :noaccess
rem The settings app, uaRO Graphics Settings, lives next to uaRO.exe.
if exist "uaro-graphics\uaro-graphics.exe" copy /y "uaro-graphics\uaro-graphics.exe" "uaro-graphics.exe" >nul || goto :noaccess
rem 2.2: dgVoodoo is no longer offered - its switches go (uninstall.bat still puts it back).
if exist "use-dgvoodoo.bat" del /f "use-dgvoodoo.bat" >nul 2>&1
if exist "use-uaro.bat" del /f "use-uaro.bat" >nul 2>&1
rem 2.8: the settings are uaro-graphics\uaro-graphics.ini, the package's template uaro-graphics\defaults (an older
rem update.bat copies uaro-graphics\ of the archive over this folder). A 2.x install's root file moves there at the
rem driver's or the settings app's start; a fresh install gets the template.
if not exist "uaro-graphics\uaro-graphics.ini" if not exist "uaro-graphics.ini" ^
    copy "uaro-graphics\defaults\uaro-graphics.ini" "uaro-graphics\uaro-graphics.ini" >nul
rem What older settings files lack goes into a 2.x install's root file before it moves; a fresh install has none.
if not exist "uaro-graphics.ini" goto :old_ini_done
rem A 0.3 settings file has no sharpen key yet: it is added at the end, every other setting stays.
findstr /c:"sharpen" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [quality]
    >>"uaro-graphics.ini" echo ; sharpening of the picture on screen, 0-100: 0 = off, more = crisper detail
    >>"uaro-graphics.ini" echo sharpen = 50
    >>"uaro-graphics.ini" echo ; in the game, Pause or Scroll Lock switches all improvements off and on, to compare
)
rem A settings file older than 0.5 has no crisp_text key: it is added at the end the same way.
findstr /c:"crisp_text" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [display]
    >>"uaro-graphics.ini" echo ; 1 = the game's text, window frames and fills at the real pixels of the window when the game is enlarged; 0 = as version 0.4
    >>"uaro-graphics.ini" echo crisp_text = 1
)
rem A settings file older than 0.7 has no msaa key: the smoothing settings are added at the end the same way, as the
rem preset the file holds has them - Speed (no sharpening, no crisp text) and No improvements (also no high resolution)
rem get less, so an update never makes a weak card work harder (0.7.0 review).
findstr /c:"msaa" "uaro-graphics.ini" >nul 2>&1
if not errorlevel 1 goto :smoothing_done
set "msaa=4"
set "a2c=1"
set "aniso=16"
findstr /i /r /c:"^ *sharpen *= *0 *$" /c:"^ *sharpen *= *0[^0-9]" "uaro-graphics.ini" >nul 2>&1 ^
    || goto :smoothing_write
findstr /i /r /c:"^ *crisp_text *= *0 *$" /c:"^ *crisp_text *= *0[^0-9]" "uaro-graphics.ini" >nul 2>&1 ^
    || goto :smoothing_write
set "msaa=0"
set "aniso=4"
findstr /i /r /c:"^ *high_resolution *= *0 *$" /c:"^ *high_resolution *= *0[^0-9]" "uaro-graphics.ini" >nul 2>&1 ^
    || goto :smoothing_write
set "a2c=0"
set "aniso=0"
:smoothing_write
>>"uaro-graphics.ini" echo.
>>"uaro-graphics.ini" echo [quality]
>>"uaro-graphics.ini" echo ; edge smoothing (MSAA): samples per pixel - 0 = off, 2, 4 or 8
>>"uaro-graphics.ini" echo msaa = %msaa%
>>"uaro-graphics.ini" echo ; 1 = with msaa, soft edges where textures are cut out (leaves, fences)
>>"uaro-graphics.ini" echo alpha_to_coverage = %a2c%
>>"uaro-graphics.ini" echo ; anisotropic filtering of the world: 0 = off, 2, 4, 8 or 16
>>"uaro-graphics.ini" echo anisotropy = %aniso%
:smoothing_done
rem 0.17: the AI textures take textures of 16 pixels and more, not 64 - shadows and a map's small things. The settings
rem file 0.12-0.16 put in place says min_size = 64 under that version's note: both change, once.
findstr /x /c:"; the textures it takes, by their sides in pixels: from min_size to max_size, 16-1024" "uaro-graphics.ini" >nul 2>&1 && findstr /x /c:"min_size = 64" "uaro-graphics.ini" >nul 2>&1 && powershell -NoProfile -ExecutionPolicy Bypass -Command "$f='uaro-graphics.ini'; (Get-Content -LiteralPath $f) -replace '^min_size = 64$','min_size = 16' -replace '^; the textures it takes, by their sides in pixels: from min_size to max_size, 16-1024$','; the textures of the world it takes, by their sides in pixels (16 since 0.17)' | Set-Content -LiteralPath $f -Encoding ASCII"
rem 0.18-0.22: the effects page's keys, off, with their notes, at the end of a settings file from before they came
rem - all of them, or 0.19's water after the [effects] 0.18 added.
findstr /i /l /c:"[effects]" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; modern effects over the game's picture with the uaro renderer, also in a running game
    >>"uaro-graphics.ini" echo ; 1 = the light of skills, portals and lamps shines with a soft glow - bloom;
    >>"uaro-graphics.ini" echo ;     the rest of the picture keeps its brightness
    >>"uaro-graphics.ini" echo glow = 0
    >>"uaro-graphics.ini" echo ; how bright the glow is, 0-200 %%; how far it spreads, 0-100 %%
    >>"uaro-graphics.ini" echo glow_strength = 100
    >>"uaro-graphics.ini" echo glow_size = 50
    >>"uaro-graphics.ini" echo ; 0-100 %%: how much the effects' light falls on what is around them
    >>"uaro-graphics.ini" echo glow_light = 50
    >>"uaro-graphics.ini" echo ; 1 = soft shadows where surfaces meet: at walls, in corners, under trees
    >>"uaro-graphics.ini" echo ao = 0
    >>"uaro-graphics.ini" echo ; 0-100 %%: how dark the shadows are, how far they reach from a corner
    >>"uaro-graphics.ini" echo ao_strength = 60
    >>"uaro-graphics.ini" echo ao_size = 50
    >>"uaro-graphics.ini" echo ; 1 = the maps' water drawn anew: waves, reflections, the sun's glints,
    >>"uaro-graphics.ini" echo ;     the bed seen through it, foam
    >>"uaro-graphics.ini" echo water = 0
    >>"uaro-graphics.ini" echo ; 0-100 %%: how rough it is - 0 = a still mirror, how much it reflects,
    >>"uaro-graphics.ini" echo ;     how deep one sees into it
    >>"uaro-graphics.ini" echo water_waves = 50
    >>"uaro-graphics.ini" echo water_reflections = 50
    >>"uaro-graphics.ini" echo water_clarity = 50
    >>"uaro-graphics.ini" echo ; 1 = the picture's colours to taste: saturation 0-200 %%, contrast and brightness
    >>"uaro-graphics.ini" echo ;     50-150 %% - 100 as the game, warmth 0-100 %% - 50 as the game, vignette 0-100 %%
    >>"uaro-graphics.ini" echo grade = 0
    >>"uaro-graphics.ini" echo grade_saturation = 115
    >>"uaro-graphics.ini" echo grade_contrast = 108
    >>"uaro-graphics.ini" echo grade_brightness = 100
    >>"uaro-graphics.ini" echo grade_warmth = 50
    >>"uaro-graphics.ini" echo grade_vignette = 25
    >>"uaro-graphics.ini" echo ; 1 = depth of field: sharp around your character, the farther and the nearer softer;
    >>"uaro-graphics.ini" echo ;     0-100 %%: how soft, how deep the sharp zone is
    >>"uaro-graphics.ini" echo dof = 0
    >>"uaro-graphics.ini" echo dof_strength = 60
    >>"uaro-graphics.ini" echo dof_range = 40
)
findstr /i /l /c:"water_waves" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the maps' water drawn anew: waves, reflections, the sun's glints,
    >>"uaro-graphics.ini" echo ;     the bed seen through it, foam
    >>"uaro-graphics.ini" echo water = 0
    >>"uaro-graphics.ini" echo ; 0-100 %%: how rough it is - 0 = a still mirror, how much it reflects,
    >>"uaro-graphics.ini" echo ;     how deep one sees into it
    >>"uaro-graphics.ini" echo water_waves = 50
    >>"uaro-graphics.ini" echo water_reflections = 50
    >>"uaro-graphics.ini" echo water_clarity = 50
)
rem 0.20: the soft shadows and the glow's light, after the [effects] 0.18 and 0.19 added.
findstr /i /l /c:"ao_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = soft shadows where surfaces meet: at walls, in corners, under trees
    >>"uaro-graphics.ini" echo ao = 0
    >>"uaro-graphics.ini" echo ; 0-100 %%: how dark the shadows are, how far they reach from a corner
    >>"uaro-graphics.ini" echo ao_strength = 60
    >>"uaro-graphics.ini" echo ao_size = 50
    >>"uaro-graphics.ini" echo ; 0-100 %%: how much the effects' light falls on what is around them
    >>"uaro-graphics.ini" echo glow_light = 50
)
rem 0.21: the colours, after the [effects] 0.18-0.20 added.
findstr /i /l /c:"grade_saturation" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the picture's colours to taste: saturation 0-200 %%, contrast and brightness
    >>"uaro-graphics.ini" echo ;     50-150 %% - 100 as the game, warmth 0-100 %% - 50 as the game, vignette 0-100 %%
    >>"uaro-graphics.ini" echo grade = 0
    >>"uaro-graphics.ini" echo grade_saturation = 115
    >>"uaro-graphics.ini" echo grade_contrast = 108
    >>"uaro-graphics.ini" echo grade_brightness = 100
    >>"uaro-graphics.ini" echo grade_warmth = 50
    >>"uaro-graphics.ini" echo grade_vignette = 25
)
rem 0.22: the depth of field, after the [effects] 0.18-0.21 added.
findstr /i /l /c:"dof_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = depth of field: sharp around your character, the farther and the nearer softer;
    >>"uaro-graphics.ini" echo ;     0-100 %%: how soft, how deep the sharp zone is
    >>"uaro-graphics.ini" echo dof = 0
    >>"uaro-graphics.ini" echo dof_strength = 60
    >>"uaro-graphics.ini" echo dof_range = 40
)
rem 0.22.6: the smooth map light, on, after the [effects] 0.18-0.22 added.
findstr /i /l /c:"smooth_light" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the map's baked light - torch pools, shadows on the ground -
    >>"uaro-graphics.ini" echo ;     smooth instead of blotches
    >>"uaro-graphics.ini" echo smooth_light = 1
)
rem 0.23: the torches drawn anew, on, after the [effects] 0.18-0.22.6 added.
findstr /i /l /c:"torch_glow" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the maps' torches drawn anew: a burning flame with sparks, a soft glow around it,
    >>"uaro-graphics.ini" echo ;     warm flickering light on the ground and the walls
    >>"uaro-graphics.ini" echo torch = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: the glow around the fire, the light it throws around; 0-100 %%: its flicker
    >>"uaro-graphics.ini" echo torch_glow = 100
    >>"uaro-graphics.ini" echo torch_light = 100
    >>"uaro-graphics.ini" echo torch_flicker = 50
)
rem 0.23.2: the torches' new flame and its brightness.
findstr /i /l /c:"torch_brightness" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the torches' new flame, 0 = the game's own flame with the new glow and light
    >>"uaro-graphics.ini" echo torch_flame = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how bright the new flame burns
    >>"uaro-graphics.ini" echo torch_brightness = 100
)
rem 0.24: the chimneys' smoke, on.
findstr /i /l /c:"smoke_density" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the chimneys' smoke billowing - wisps and gaps that rise - instead of one picture
    >>"uaro-graphics.ini" echo smoke = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how thick the smoke is
    >>"uaro-graphics.ini" echo smoke_density = 100
)
rem 0.25: the lamps' light from the map files, on.
findstr /i /l /c:"lamps_light" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the maps' lamps light the characters and walls too, the fire-coloured ones flicker
    >>"uaro-graphics.ini" echo lamps = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how bright the lamps' light is
    >>"uaro-graphics.ini" echo lamps_light = 60
)
rem 0.26: the fire of skills lights around it, on.
findstr /i /l /c:"fire_light_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = fire walls, fire bolts and other fire-coloured skills light around them a little
    >>"uaro-graphics.ini" echo fire_light = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how much
    >>"uaro-graphics.ini" echo fire_light_strength = 100
)
rem 0.36: the other skills light in their colours, on.
findstr /i /l /c:"skill_colours" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the other skills light too, each in its colour: ice blue, lightning white, holy gold
    >>"uaro-graphics.ini" echo skill_colours = 1
)
rem 0.27: the level 99 aura softer, on.
findstr /i /l /c:"aura_brightness" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the level 99 aura - its ring, bubbles and circle - shines softer
    >>"uaro-graphics.ini" echo aura = 1
    >>"uaro-graphics.ini" echo ; 0-100 %%: how bright the aura is, of what the game draws
    >>"uaro-graphics.ini" echo aura_brightness = 50
)
rem 0.37: softer skills, on.
findstr /i /l /c:"skill_brightness" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = skills and the other effects of the game shine a little softer
    >>"uaro-graphics.ini" echo skills_soft = 1
    >>"uaro-graphics.ini" echo ; 0-100 %%: how bright, of what the game draws
    >>"uaro-graphics.ini" echo skill_brightness = 80
)
rem 0.28: the maps' fireflies drawn anew, on.
findstr /i /l /c:"fireflies_brightness" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the maps' fireflies glow, flash now and then and light a little around them
    >>"uaro-graphics.ini" echo fireflies = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how bright the fireflies and their light are
    >>"uaro-graphics.ini" echo fireflies_brightness = 100
)
rem 0.29: the maps' hidden lights drawn from their files, on.
findstr /i /l /c:"map_glows_brightness" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = glows, pools of light and dust the maps' makers placed but the game never showed
    >>"uaro-graphics.ini" echo map_glows = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how bright they and their light are
    >>"uaro-graphics.ini" echo map_glows_brightness = 100
)
rem 0.30: the forest's beams of light drawn anew, on.
findstr /i /l /c:"rays_brightness" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the forest's beams of light soft, shimmering, with dust and light where they fall
    >>"uaro-graphics.ini" echo rays = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how bright the beams and their light are
    >>"uaro-graphics.ini" echo rays_brightness = 100
)
rem 0.31: living lava, on.
findstr /i /l /c:"lava_brightness" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = lava flows: its crust drifts, its cracks glow, its heat lights what is around it
    >>"uaro-graphics.ini" echo lava = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how brightly the lava glows and lights around it
    >>"uaro-graphics.ini" echo lava_brightness = 100
)
rem 0.38: living portals, on.
findstr /i /l /c:"portals_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the warps and the skill's portals glow around in soft blue, the air turns in them
    >>"uaro-graphics.ini" echo portals = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how bright the glow, how strong the swirl
    >>"uaro-graphics.ini" echo portals_strength = 100
)
rem 0.32: the characters' shadows from their sprites, on.
findstr /i /l /c:"actor_shadows_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = characters and monsters cast soft shadows the shape of their sprites
    >>"uaro-graphics.ini" echo actor_shadows = 1
    >>"uaro-graphics.ini" echo ; 0-100 %%: how dark
    >>"uaro-graphics.ini" echo actor_shadows_strength = 55
)
rem 0.33: clouds' shadows over the fields and towns, on.
findstr /i /l /c:"clouds_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = clouds' shadows drift over the fields and the towns
    >>"uaro-graphics.ini" echo clouds = 1
    >>"uaro-graphics.ini" echo ; 0-100 %%: how dark
    >>"uaro-graphics.ini" echo clouds_strength = 50
)
rem 0.34: haze and the dungeons' low fog, on.
findstr /i /l /c:"haze_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = a light haze far off outside; in the dungeons the dark far off and a low fog
    >>"uaro-graphics.ini" echo haze = 1
    >>"uaro-graphics.ini" echo ; 0-100 %%: how thick
    >>"uaro-graphics.ini" echo haze_strength = 50
)
rem 0.35: heat haze, on.
findstr /i /l /c:"heat_strength" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = the picture shimmers over flames, burning skills, lava and far off in the desert
    >>"uaro-graphics.ini" echo heat = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how much
    >>"uaro-graphics.ini" echo heat_strength = 100
)
rem 0.39: the driver's own weather, on.
findstr /i /l /c:"weather_amount" "uaro-graphics.ini" >nul 2>&1
if errorlevel 1 (
    >>"uaro-graphics.ini" echo.
    >>"uaro-graphics.ini" echo [effects]
    >>"uaro-graphics.ini" echo ; 1 = snow over Lutie, leaves in Payon, sand about Morroc, rain over Niflheim and Einbroch
    >>"uaro-graphics.ini" echo weather = 1
    >>"uaro-graphics.ini" echo ; 0-200 %%: how much of it
    >>"uaro-graphics.ini" echo weather_amount = 100
)
:old_ini_done
rem 1.4: uaRO Pad, the gamepad, switched on on the Gamepad page gets the package's version. A running game keeps
rem the old one in use: it is updated next time.
if exist "dinput.dll" if exist "uaro-graphics\pad\dinput.dll" (
    findstr /m /c:"uaro-pad.ini" "dinput.dll" >nul 2>&1 && copy /y "uaro-graphics\pad\dinput.dll" "dinput.dll" >nul 2>&1
)
rem Part 3: NVIDIA DLSS's own package, downloaded when it is missing or another version (get-dlss.bat).
if exist "get-dlss.bat" call get-dlss.bat /quiet
rem update.bat calls install.bat /quiet and reports the result itself.
if /i "%~1"=="/quiet" exit /b 0
echo.
echo uaRO Graphics is installed. Start the game as usual.
echo Every setting is in uaro-graphics.exe (uaRO Graphics Settings) in this folder.
echo The logs are in uaro-graphics\logs. To undo everything, run uninstall.bat.
echo.
pause
exit /b 0

:noaccess
echo.
echo Cannot write to this folder. Right-click install.bat and choose "Run as administrator".
:fail
echo.
if /i not "%~1"=="/quiet" pause
exit /b 1
